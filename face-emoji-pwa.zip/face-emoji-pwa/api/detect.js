export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { image } = req.body;
  if (!image) return res.status(400).json({ error: 'No image provided' });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'API key not configured' });

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 256,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: 'image/jpeg', data: image }
            },
            {
              type: 'text',
              text: `Look at this face photo and identify the facial expression.
Return ONLY a valid JSON object with no extra text:
{
  "main": "<single best emoji>",
  "emojis": ["<emoji1>","<emoji2>","<emoji3>"],
  "labels": ["<Hebrew label1>","<Hebrew label2>","<Hebrew label3>"],
  "expression": "<expression name in Hebrew>"
}

Expression options: שמח, עצוב, כועס, מופתע, מפוחד, גועל, בוז, נייטרלי, צוחק, מחייך, רציני, מהורהר, עייף, נרגש.
If no face: {"main":"🤷","emojis":["🤷","😶","❓"],"labels":["לא זוהה","נסה שוב","?"],"expression":"לא זוהה פנים"}
Return ONLY JSON.`
            }
          ]
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.[0]?.text || '{}';

    let result;
    try {
      result = JSON.parse(text.trim());
    } catch {
      // Try to extract JSON from response
      const match = text.match(/\{[\s\S]*\}/);
      result = match ? JSON.parse(match[0]) : {
        main: '😐',
        emojis: ['😐', '🤔', '😶'],
        labels: ['נייטרלי', 'מהורהר', 'ריק'],
        expression: 'לא ברור'
      };
    }

    res.status(200).json(result);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Analysis failed' });
  }
}
